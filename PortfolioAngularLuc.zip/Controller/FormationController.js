app.controller("formationController", ['$scope', function($scope) {
	$scope.formations = [
		{
			name: "Master Informatique",
			descr: "Architecture et InGénierie du Logiciel et du wEb",
			location: "Université de Montpellier 2"
		},
		{
			name: "Licence Informatique",
			descr: "",
			location: "Université de Montpellier 2"
		}
	]
}]);